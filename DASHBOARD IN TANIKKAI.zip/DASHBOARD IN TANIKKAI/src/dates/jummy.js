import Oval1 from './imgs/Oval1.png'
import Oval2 from './imgs/Oval2.png'
import Oval3 from './imgs/Oval3.png'
import Oval4 from './imgs/Oval4.png'
import pl from './imgs/Placeholder.png'
import pl1 from './imgs/Placeholder (1).png'
import pl2 from './imgs/Placeholder (2).png'
import pl3 from './imgs/Placeholder (3).png'
import pl4 from './imgs/Placeholder (4).png'
import pl5 from './imgs/Placeholder (5).png'
export let Data = [
    {
        icon: 'fa-solid fa-chart-pie',
        inside: [
            {
                icon: 'fa-solid fa-chart-pie',
                text: 'Dashboard',
                url: 'main'
            },
           
        ]
    },
    {
        icon: 'fa-solid fa-mug-saucer',
        inside: [
            {
                icon: 'fa-solid fa-chart-pie',
                text: 'Dashboard',
                url: 'main'
            },
            {
                icon: 'fa-solid fa-mug-saucer',
                text: 'Policies',
                url: 'marketing'
            },
           
        ]
    },
    {
        icon: 'fa-solid fa-chart-simple',
        inside: [
            {
                icon: 'fa-solid fa-chart-pie',
                text: 'Dashboard',
                url: 'main'
            },
            {
                icon: 'fa-solid fa-mug-saucer',
                text: 'Policies',
                url: 'marketing'
            },
            {
                icon: 'fa-solid fa-chart-simple',
                text: 'Security Traning',
                url: 'main'
            },
            
        ]
    },
    {
        icon: 'fa-solid fa-calendar-days',
        inside: [
            {
                icon: 'fa-solid fa-chart-pie',
                text: 'Dashboard',
                url: 'main'
            },
            {
                icon: 'fa-solid fa-mug-saucer',
                text: 'Policies',
                url: 'marketing'
            },
            {
                icon: 'fa-solid fa-chart-simple',
                text: 'Security Traning',
                url: 'main'
            },
            {
                icon: 'fa-solid fa-calendar-days',
                text: 'Report Incident',
                url: 'main'
            },
        ]
    },
    {
        icon: 'fa-solid fa-box',
        inside: [
            {
                icon: 'fa-solid fa-chart-pie',
                text: 'Dashboard',
                url: 'main'
            },
            {
                icon: 'fa-solid fa-mug-saucer',
                text: 'Policies',
                url: 'marketing'
            },
            {
                icon: 'fa-solid fa-chart-simple',
                text: 'Security Traning',
                url: 'main'
            },
            {
                icon: 'fa-solid fa-calendar-days',
                text: 'Report Incident',
                url: 'main'
            },
            {
                icon: 'fa-solid fa-box',
                text: 'Multifactor Auth',
                url: 'main'
            },
        ]
    },
   
]


export let dateCards = [
    {
       
    },

]
export let topSellingAndGrossingItems = [
    {
        title: 'Top selling items',
        items: [
            {
               
            }
        ]
    },
    {
        title: 'Top grossing items',
        items: [
            {
               
            }
        ]
    }
]
export let dateStaff = [
    {
       
    },
]

export let dataPie = [
    {
       
    },
]
export let dataColumn = [
    {
       
    },
]


export const dataLine = [[
    
],]

export let dataBar = [
    {
       
    },
]


export let dateOptions = [
    {
       
    
       
        
   
    },
]

export let cards = [
    {
       
    }
]


export let multilocation = [
    {
        
    },
]
export let time = [
]